-- phpMyAdmin SQL Dump
-- version 4.2.10
-- http://www.phpmyadmin.net
--
-- Host: localhost:3306
-- Generation Time: Jan 13, 2015 at 03:48 PM
-- Server version: 5.5.38
-- PHP Version: 5.6.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `testWeb`
--
CREATE DATABASE IF NOT EXISTS `testWeb` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `testWeb`;

-- --------------------------------------------------------

--
-- Table structure for table `accoutInfo`
--

CREATE TABLE `accoutInfo` (
  `AccountId` int(10) NOT NULL,
  `lastName` varchar(10) NOT NULL,
  `firstName` varchar(10) NOT NULL,
  `age` int(3) NOT NULL,
  `accountName` varchar(100) NOT NULL,
  `password` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `bookClub_configuration`
--

CREATE TABLE `bookClub_configuration` (
`id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `value` varchar(150) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `bookClub_configuration`
--

INSERT INTO `bookClub_configuration` (`id`, `name`, `value`) VALUES
(1, 'website_name', 'BookClub'),
(2, 'website_url', 'localhost/bookclub/accountM/'),
(3, 'email', 'xingchen.peter.li@gmail.com'),
(4, 'activation', '1'),
(5, 'resend_activation_threshold', '0'),
(6, 'language', 'models/languages/en.php'),
(8, 'can_register', '1'),
(9, 'new_user_title', 'New Member'),
(11, 'email_login', '0'),
(12, 'token_timeout', '10800'),
(13, 'version', '0.2.2');

-- --------------------------------------------------------

--
-- Table structure for table `bookClub_filelist`
--

CREATE TABLE `bookClub_filelist` (
`id` int(11) NOT NULL,
  `path` varchar(150) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bookClub_filelist`
--

INSERT INTO `bookClub_filelist` (`id`, `path`) VALUES
(1, 'account'),
(2, 'forms');

-- --------------------------------------------------------

--
-- Table structure for table `bookClub_groups`
--

CREATE TABLE `bookClub_groups` (
`id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `is_default` tinyint(1) NOT NULL,
  `can_delete` tinyint(1) NOT NULL,
  `home_page_id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `bookClub_groups`
--

INSERT INTO `bookClub_groups` (`id`, `name`, `is_default`, `can_delete`, `home_page_id`) VALUES
(1, 'User', 2, 0, 4),
(2, 'Administrator', 0, 0, 5);

-- --------------------------------------------------------

--
-- Table structure for table `bookClub_group_action_permits`
--

CREATE TABLE `bookClub_group_action_permits` (
`id` int(10) unsigned NOT NULL,
  `group_id` int(11) NOT NULL,
  `action` varchar(100) NOT NULL,
  `permits` varchar(400) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `bookClub_group_action_permits`
--

INSERT INTO `bookClub_group_action_permits` (`id`, `group_id`, `action`, `permits`) VALUES
(1, 1, 'updateUserEmail', 'isLoggedInUser(user_id)'),
(2, 1, 'updateUserPassword', 'isLoggedInUser(user_id)'),
(3, 1, 'loadUser', 'isLoggedInUser(user_id)'),
(4, 1, 'loadUserGroups', 'isLoggedInUser(user_id)'),
(5, 2, 'updateUserEmail', 'always()'),
(6, 2, 'updateUserPassword', 'always()'),
(7, 2, 'updateUser', 'always()'),
(8, 2, 'updateUserDisplayName', 'always()'),
(9, 2, 'updateUserTitle', 'always()'),
(10, 2, 'updateUserEnabled', 'always()'),
(11, 2, 'loadUser', 'always()'),
(12, 2, 'loadUserGroups', 'always()'),
(13, 2, 'loadUsers', 'always()'),
(14, 2, 'deleteUser', 'always()'),
(15, 2, 'activateUser', 'always()'),
(16, 2, 'loadGroups', 'always()');

-- --------------------------------------------------------

--
-- Table structure for table `bookClub_group_page_matches`
--

CREATE TABLE `bookClub_group_page_matches` (
`id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `page_id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `bookClub_group_page_matches`
--

INSERT INTO `bookClub_group_page_matches` (`id`, `group_id`, `page_id`) VALUES
(1, 1, 1),
(3, 2, 3),
(4, 2, 4),
(5, 2, 5),
(6, 2, 6),
(7, 2, 7),
(8, 2, 8),
(9, 2, 9),
(10, 2, 10),
(11, 2, 11),
(12, 2, 12),
(13, 2, 13),
(14, 2, 14),
(15, 2, 15),
(16, 2, 16),
(19, 1, 3),
(20, 1, 4),
(21, 1, 6),
(22, 1, 13),
(23, 1, 15),
(24, 1, 17),
(25, 1, 18),
(26, 1, 19),
(27, 2, 17),
(28, 2, 18),
(29, 2, 19);

-- --------------------------------------------------------

--
-- Table structure for table `bookClub_nav`
--

CREATE TABLE `bookClub_nav` (
`id` int(11) NOT NULL,
  `menu` varchar(75) NOT NULL,
  `page` varchar(175) NOT NULL,
  `name` varchar(150) NOT NULL,
  `position` int(11) NOT NULL,
  `class_name` varchar(150) NOT NULL,
  `icon` varchar(150) NOT NULL,
  `parent_id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `bookClub_nav`
--

INSERT INTO `bookClub_nav` (`id`, `menu`, `page`, `name`, `position`, `class_name`, `icon`, `parent_id`) VALUES
(1, 'left', 'account/dashboard_admin.php', 'Admin Dashboard', 3, 'dashboard-admin', 'fa fa-dashboard', 0),
(2, 'left', 'account/users.php', 'Users', 2, 'users', 'fa fa-users', 0),
(3, 'left', 'account/dashboard.php', 'Dashboard', 3, 'dashboard', 'fa fa-dashboard', 0),
(4, 'left', 'account/account_settings.php', 'Account Settings', 4, 'settings', 'fa fa-gear', 0),
(5, 'left-sub', '#', 'Site Settings', 5, '', 'fa fa-wrench', 0),
(6, 'left-sub', 'account/site_settings.php', 'Site Configuration', 6, 'site-settings', 'fa fa-globe', 5),
(7, 'left-sub', 'account/groups.php', 'Groups', 7, 'groups', 'fa fa-users', 5),
(8, 'left-sub', 'account/site_authorization.php', 'Authorization', 8, 'site-pages', 'fa fa-key', 5),
(9, 'top-main-sub', '#', '#USERNAME#', 1, 'site-settings', 'fa fa-user', 0),
(10, 'top-main-sub', 'account/account_settings.php', 'Account Settings', 1, '', 'fa fa-gear', 9),
(11, 'top-main-sub', 'account/logout.php', 'Log Out', 2, '', 'fa fa-power-off', 9),
(12, 'left', 'account/loginHome.php', 'Home', 1, 'home', 'fa fa-home', 0),
(13, 'left', 'account/logInBook.php', 'Book', 10, 'book', 'fa fa-book', 0),
(14, 'left', 'account/circle.php', 'Circle', 11, 'circle', 'fa fa-user', 0),
(15, 'left', 'account/logInNews.php', 'School News', 12, 'news', 'fa fa-th-list', 0);

-- --------------------------------------------------------

--
-- Table structure for table `bookClub_nav_group_matches`
--

CREATE TABLE `bookClub_nav_group_matches` (
`id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `bookClub_nav_group_matches`
--

INSERT INTO `bookClub_nav_group_matches` (`id`, `menu_id`, `group_id`) VALUES
(1, 3, 1),
(2, 4, 1),
(3, 9, 1),
(4, 10, 1),
(5, 11, 1),
(6, 1, 2),
(7, 2, 2),
(8, 5, 2),
(9, 6, 2),
(10, 7, 2),
(11, 8, 2),
(12, 12, 1),
(13, 13, 1),
(14, 14, 1),
(15, 15, 1);

-- --------------------------------------------------------

--
-- Table structure for table `bookClub_pages`
--

CREATE TABLE `bookClub_pages` (
`id` int(11) NOT NULL,
  `page` varchar(150) NOT NULL,
  `private` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `bookClub_pages`
--

INSERT INTO `bookClub_pages` (`id`, `page`, `private`) VALUES
(1, 'forms/table_users.php', 1),
(3, 'account/logout.php', 1),
(4, 'account/dashboard.php', 1),
(5, 'account/dashboard_admin.php', 1),
(6, 'account/account_settings.php', 1),
(7, 'account/site_authorization.php', 1),
(8, 'account/site_settings.php', 1),
(9, 'account/users.php', 1),
(10, 'account/user_details.php', 1),
(11, 'account/index.php', 0),
(12, 'account/groups.php', 1),
(13, 'forms/form_user.php', 1),
(14, 'forms/form_group.php', 1),
(15, 'forms/form_confirm_delete.php', 1),
(16, 'forms/form_action_permits.php', 1),
(17, 'account/loginHome.html', 1),
(18, '../logInBook.html', 1),
(19, '../circle.html', 1);

-- --------------------------------------------------------

--
-- Table structure for table `bookClub_plugin_configuration`
--

CREATE TABLE `bookClub_plugin_configuration` (
`id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `value` varchar(150) NOT NULL,
  `binary` int(1) NOT NULL,
  `variable` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `bookClub_users`
--

CREATE TABLE `bookClub_users` (
`id` int(11) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `display_name` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(150) NOT NULL,
  `activation_token` varchar(225) NOT NULL,
  `last_activation_request` int(11) NOT NULL,
  `lost_password_request` tinyint(1) NOT NULL,
  `lost_password_timestamp` int(11) DEFAULT NULL,
  `active` tinyint(1) NOT NULL,
  `title` varchar(150) NOT NULL,
  `sign_up_stamp` int(11) NOT NULL,
  `last_sign_in_stamp` int(11) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'Specifies if the account is enabled.  Disabled accounts cannot be logged in to, but they retain all of their data and settings.',
  `primary_group_id` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'Specifies the primary group for the user.'
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `bookClub_users`
--

INSERT INTO `bookClub_users` (`id`, `user_name`, `display_name`, `password`, `email`, `activation_token`, `last_activation_request`, `lost_password_request`, `lost_password_timestamp`, `active`, `title`, `sign_up_stamp`, `last_sign_in_stamp`, `enabled`, `primary_group_id`) VALUES
(1, 'xingchenLi', 'Li Xingchen', '$2y$10$Enqpj5lX5jQukjN.LEGwReHmvO8FA7b1qqWXMuUO9vN8pCxBEKwlG', 'xingchen.peter.li@gmail.com', 'ca773582f4fc4cda2bf0e8c43e5b6fa5', 1417320802, 0, 1417320802, 1, 'Master Account', 1417320802, 1421116624, 1, 2),
(4, 'huda', 'huda', '$2y$10$jD43qxVY5RjcMrWTVIvB7eSa/t3UkYdxMF/vpZaD.F9W0XFhOHoOi', 'hdua@sina.com', '9167de6f2f6a5bfd6326a4c7c284f5cf', 1420248926, 0, 1420248926, 1, 'New Member', 1420248926, 1421116591, 1, 1),
(5, 'terry', 'terry', '$2y$10$ZShL.4z6PTAxGhKSmC2xVumaetwPvH0nN9vG3WDZLcGPS1T5ILmLe', 'asdas@gmail.com', 'a2150f09314d94a4da895cd39530866c', 1420417943, 0, 1420417943, 1, 'New User', 1420417943, 0, 1, 1),
(6, 'shit', 'ha', '$2y$10$9WegUWoO723dXORZIAVb4OojPaqvYAcuJ3sCT.xivgIZVk2EC58PK', 'adkja@gmail.com', 'e8be1fbcb775c05726d669da858d8153', 1420417991, 0, 1420417991, 1, 'New User', 1420417991, 0, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `bookClub_user_action_permits`
--

CREATE TABLE `bookClub_user_action_permits` (
`id` int(10) unsigned NOT NULL,
  `user_id` int(11) NOT NULL,
  `action` varchar(100) NOT NULL,
  `permits` varchar(400) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `bookClub_user_group_matches`
--

CREATE TABLE `bookClub_user_group_matches` (
`id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `bookClub_user_group_matches`
--

INSERT INTO `bookClub_user_group_matches` (`id`, `user_id`, `group_id`) VALUES
(1, 1, 1),
(2, 1, 2),
(6, 4, 1),
(7, 5, 2),
(8, 5, 1),
(9, 6, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accoutInfo`
--
ALTER TABLE `accoutInfo`
 ADD PRIMARY KEY (`AccountId`);

--
-- Indexes for table `bookClub_configuration`
--
ALTER TABLE `bookClub_configuration`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bookClub_filelist`
--
ALTER TABLE `bookClub_filelist`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `path` (`path`);

--
-- Indexes for table `bookClub_groups`
--
ALTER TABLE `bookClub_groups`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bookClub_group_action_permits`
--
ALTER TABLE `bookClub_group_action_permits`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bookClub_group_page_matches`
--
ALTER TABLE `bookClub_group_page_matches`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bookClub_nav`
--
ALTER TABLE `bookClub_nav`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bookClub_nav_group_matches`
--
ALTER TABLE `bookClub_nav_group_matches`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bookClub_pages`
--
ALTER TABLE `bookClub_pages`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bookClub_plugin_configuration`
--
ALTER TABLE `bookClub_plugin_configuration`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bookClub_users`
--
ALTER TABLE `bookClub_users`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bookClub_user_action_permits`
--
ALTER TABLE `bookClub_user_action_permits`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bookClub_user_group_matches`
--
ALTER TABLE `bookClub_user_group_matches`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bookClub_configuration`
--
ALTER TABLE `bookClub_configuration`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `bookClub_filelist`
--
ALTER TABLE `bookClub_filelist`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `bookClub_groups`
--
ALTER TABLE `bookClub_groups`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `bookClub_group_action_permits`
--
ALTER TABLE `bookClub_group_action_permits`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `bookClub_group_page_matches`
--
ALTER TABLE `bookClub_group_page_matches`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=30;
--
-- AUTO_INCREMENT for table `bookClub_nav`
--
ALTER TABLE `bookClub_nav`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `bookClub_nav_group_matches`
--
ALTER TABLE `bookClub_nav_group_matches`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `bookClub_pages`
--
ALTER TABLE `bookClub_pages`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `bookClub_plugin_configuration`
--
ALTER TABLE `bookClub_plugin_configuration`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `bookClub_users`
--
ALTER TABLE `bookClub_users`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `bookClub_user_action_permits`
--
ALTER TABLE `bookClub_user_action_permits`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `bookClub_user_group_matches`
--
ALTER TABLE `bookClub_user_group_matches`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
