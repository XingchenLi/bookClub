<?php
header('Location: ../404.php');
